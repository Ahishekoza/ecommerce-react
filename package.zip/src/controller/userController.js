import user from '../models/userModel.js'


export const register = async(req,res) =>{
    const {name,email,password} = req.body

    await user.create({name:name,email:email,password:password}).then((user)=>{
        return res.status(200).json({
            success: true,
            message:"User created successfully",
            User: user
        })
    }).catch((err)=>{
        return res.status(400).json({
            success: false,
            message: `Failed to create user${err.message}`
        })
    })
}

export const login = async(req, res) => {
    const {email,password}= req.body

    await user.findOne({email: email}).then((user)=>{
        if(password === user.password){
            return res.status(200).json({
                success: true,
                User: user
            })
        }
        else{
            return res.status(403).json({
                success: false,
                message: 'Invalid password'
            })  
        }
    }).catch((err)=>{
        return res.status(400).json({
            success: false,
            message: `${err.message}`
        })
    });
}