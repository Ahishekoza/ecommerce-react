import mongoose from 'mongoose';
import dotenv from  'dotenv'

dotenv.config()

export const connectDB = async() => {
    try {
        const cont = await mongoose.connect(`${process.env.MONGO_URL}`)
        console.log(`You have successfully connected to ${cont.connection.host}`)
    } catch (error) {
        console.log(error)
    }
}